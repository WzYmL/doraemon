package org.iso_relax.verifier;


// Referenced classes of package org.iso_relax.verifier:
//            VerifierFactory

public interface VerifierFactoryLoader {

    public abstract VerifierFactory createFactory(String s);
}
